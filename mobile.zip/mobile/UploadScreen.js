import React, { useState } from "react";
import { Button, View, Text } from "react-native";
import DocumentPicker from "react-native-document-picker";

export default function UploadScreen() {
  const [file, setFile] = useState(null);
  const [region, setRegion] = useState("NA");

  const pickFile = async () => {
    try {
      const res = await DocumentPicker.pickSingle({ type: [DocumentPicker.types.video] });
      setFile(res);
    } catch (err) {}
  };

  const upload = async () => {
    const formData = new FormData();
    formData.append("file", { uri: file.uri, name: file.name, type: file.type });
    formData.append("region", region);
    formData.append("type", "video");

    const resp = await fetch("https://localhost/api/media/upload", {
      method: "POST",
      headers: {
        "Authorization": "Bearer YOUR_JWT_TOKEN",
        "X-Region-ID": region
      },
      body: formData
    });
    const data = await resp.json();
    alert(JSON.stringify(data));
  };

  return (
    <View>
      <Button title="Pick Video" onPress={pickFile} />
      <Button title="Upload" onPress={upload} disabled={!file} />
      {file && <Text>Selected: {file.name}</Text>}
    </View>
  );
}