package com.example.deepfakedetector

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import java.io.InputStream

class UploadActivity : AppCompatActivity() {
    private val PICK_VIDEO = 1
    private var selectedUri: Uri? = null
    private val client = OkHttpClient()
    private lateinit var regionSpinner: Spinner
    private val regions = arrayOf("NA", "EU", "APAC")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upload)

        val pickButton = findViewById<Button>(R.id.pickButton)
        val uploadButton = findViewById<Button>(R.id.uploadButton)
        regionSpinner = findViewById(R.id.regionSpinner)

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, regions)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        regionSpinner.adapter = adapter

        pickButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT)
            intent.type = "video/mp4"
            startActivityForResult(intent, PICK_VIDEO)
        }

        uploadButton.setOnClickListener {
            val region = regionSpinner.selectedItem.toString()
            selectedUri?.let { uri -> uploadVideo(uri, region) }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_VIDEO && resultCode == Activity.RESULT_OK) {
            selectedUri = data?.data
            Toast.makeText(this, "Selected: $selectedUri", Toast.LENGTH_SHORT).show()
        }
    }

    private fun uploadVideo(uri: Uri, region: String) {
        val inputStream: InputStream? = contentResolver.openInputStream(uri)
        val videoBytes = inputStream?.readBytes()
        inputStream?.close()
        if (videoBytes == null) {
            Toast.makeText(this, "Could not read video", Toast.LENGTH_SHORT).show()
            return
        }

        val requestBody = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart(
                "file", "video.mp4",
                RequestBody.create("video/mp4".toMediaTypeOrNull(), videoBytes)
            )
            .addFormDataPart("region", region)
            .addFormDataPart("type", "video")
            .build()

        val request = Request.Builder()
            .url("https://localhost/api/media/upload")
            .post(requestBody)
            .addHeader("Authorization", "Bearer YOUR_JWT_TOKEN")
            .addHeader("X-Region-ID", region)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: java.io.IOException) {
                runOnUiThread {
                    Toast.makeText(this@UploadActivity, "Upload failed: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
            }
            override fun onResponse(call: Call, response: Response) {
                runOnUiThread {
                    Toast.makeText(this@UploadActivity, "Upload complete: ${response.body?.string()}", Toast.LENGTH_SHORT).show()
                }
            }
        })
    }
}